// ═══════════════════════════════════════════════════════
//  Apna Map — Service Worker (Offline Support)
//  Caches all app assets + Google Satellite tiles
// ═══════════════════════════════════════════════════════

const CACHE_NAME = 'apna-map-v1';
const TILE_CACHE = 'apna-map-tiles-v1';

// All static app assets to pre-cache
const STATIC_ASSETS = [
  './',
  './index.html',
  './resources/ol.css',
  './resources/ol.js',
  './resources/qgis2web.css',
  './resources/qgis2web.js',
  './resources/qgis2web_expressions.js',
  './resources/functions.js',
  './resources/proj4.js',
  './resources/ol-layerswitcher.css',
  './resources/ol-layerswitcher.js',
  './resources/Autolinker.min.js',
  './resources/fontawesome-all.min.css',
  './resources/photon-geocoder-autocomplete.min.css',
  './resources/photon-geocoder-autocomplete.min.js',
  './resources/horsey.min.css',
  './resources/horsey.min.js',
  './resources/marker.png',
  './resources/lds-roller.gif',
  './resources/measure-control.png',
  './resources/ic_location_on_128_28437.png',
  './webfonts/fa-solid-900.woff2',
  './webfonts/fa-solid-900.ttf',
  './layers/layers.js',
  './layers/KotlaAhmad_2.js',
  './layers/KotlaBakhu_4.js',
  './layers/Kotla_AhmadKilla_1.js',
  './layers/Kotla_BakhuKilla_3.js',
  './layers/SoinKilla_5.js',
  './layers/Soin_6.js',
  './styles/KotlaAhmad_2_style.js',
  './styles/KotlaBakhu_4_style.js',
  './styles/Kotla_AhmadKilla_1_style.js',
  './styles/Kotla_BakhuKilla_3_style.js',
  './styles/SoinKilla_5_style.js',
  './styles/Soin_6_style.js',
  './styles/legend/KotlaAhmad_2.png',
  './styles/legend/KotlaBakhu_4.png',
  './styles/legend/Kotla_AhmadKilla_1.png',
  './styles/legend/Kotla_BakhuKilla_3.png',
  './styles/legend/SoinKilla_5.png',
  './styles/legend/Soin_6.png',
];

// ── Install: pre-cache all static assets ──
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      console.log('[SW] Pre-caching app assets');
      return cache.addAll(STATIC_ASSETS);
    }).then(function() {
      return self.skipWaiting();
    })
  );
});

// ── Activate: clean old caches ──
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(
        keys.filter(function(key) {
          return key !== CACHE_NAME && key !== TILE_CACHE;
        }).map(function(key) {
          console.log('[SW] Deleting old cache:', key);
          return caches.delete(key);
        })
      );
    }).then(function() {
      return self.clients.claim();
    })
  );
});

// ── Fetch: serve from cache, fall back to network ──
self.addEventListener('fetch', function(event) {
  var url = event.request.url;

  // Google satellite tiles — cache with stale-while-revalidate
  if (url.includes('mt1.google.com') || url.includes('mt0.google.com') ||
      url.includes('mt2.google.com') || url.includes('mt3.google.com')) {
    event.respondWith(
      caches.open(TILE_CACHE).then(function(cache) {
        return cache.match(event.request).then(function(cached) {
          var fetchPromise = fetch(event.request).then(function(response) {
            if (response && response.status === 200) {
              cache.put(event.request, response.clone());
            }
            return response;
          }).catch(function() { return cached; });
          return cached || fetchPromise;
        });
      })
    );
    return;
  }

  // App assets — cache-first
  event.respondWith(
    caches.match(event.request).then(function(cached) {
      if (cached) return cached;
      return fetch(event.request).then(function(response) {
        if (!response || response.status !== 200 || response.type === 'opaque') {
          return response;
        }
        return caches.open(CACHE_NAME).then(function(cache) {
          cache.put(event.request, response.clone());
          return response;
        });
      }).catch(function() {
        // Offline fallback for navigation requests
        if (event.request.mode === 'navigate') {
          return caches.match('./index.html');
        }
      });
    })
  );
});

ol.proj.proj4.register(proj4);
//ol.proj.get("EPSG:4326").setExtent([70.330224, 29.096173, 70.476878, 29.164728]);
var wms_layers = [];


        var lyr_GoogleSatellite_0 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_Kotla_AhmadKilla_1 = new ol.format.GeoJSON();
var features_Kotla_AhmadKilla_1 = format_Kotla_AhmadKilla_1.readFeatures(json_Kotla_AhmadKilla_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_Kotla_AhmadKilla_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Kotla_AhmadKilla_1.addFeatures(features_Kotla_AhmadKilla_1);
var lyr_Kotla_AhmadKilla_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Kotla_AhmadKilla_1, 
                style: style_Kotla_AhmadKilla_1,
                popuplayertitle: 'Kotla_Ahmad Killa',
                interactive: true,
                title: '<img src="styles/legend/Kotla_AhmadKilla_1.png" /> Kotla_Ahmad Killa'
            });
var format_KotlaAhmad_2 = new ol.format.GeoJSON();
var features_KotlaAhmad_2 = format_KotlaAhmad_2.readFeatures(json_KotlaAhmad_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_KotlaAhmad_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_KotlaAhmad_2.addFeatures(features_KotlaAhmad_2);
var lyr_KotlaAhmad_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_KotlaAhmad_2, 
                style: style_KotlaAhmad_2,
                popuplayertitle: 'Kotla Ahmad',
                interactive: true,
                title: '<img src="styles/legend/KotlaAhmad_2.png" /> Kotla Ahmad'
            });
var format_Kotla_BakhuKilla_3 = new ol.format.GeoJSON();
var features_Kotla_BakhuKilla_3 = format_Kotla_BakhuKilla_3.readFeatures(json_Kotla_BakhuKilla_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_Kotla_BakhuKilla_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Kotla_BakhuKilla_3.addFeatures(features_Kotla_BakhuKilla_3);
var lyr_Kotla_BakhuKilla_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Kotla_BakhuKilla_3, 
                style: style_Kotla_BakhuKilla_3,
                popuplayertitle: 'Kotla_Bakhu Killa',
                interactive: true,
                title: '<img src="styles/legend/Kotla_BakhuKilla_3.png" /> Kotla_Bakhu Killa'
            });
var format_KotlaBakhu_4 = new ol.format.GeoJSON();
var features_KotlaBakhu_4 = format_KotlaBakhu_4.readFeatures(json_KotlaBakhu_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_KotlaBakhu_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_KotlaBakhu_4.addFeatures(features_KotlaBakhu_4);
var lyr_KotlaBakhu_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_KotlaBakhu_4, 
                style: style_KotlaBakhu_4,
                popuplayertitle: 'Kotla Bakhu',
                interactive: true,
                title: '<img src="styles/legend/KotlaBakhu_4.png" /> Kotla Bakhu'
            });
var format_SoinKilla_5 = new ol.format.GeoJSON();
var features_SoinKilla_5 = format_SoinKilla_5.readFeatures(json_SoinKilla_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_SoinKilla_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_SoinKilla_5.addFeatures(features_SoinKilla_5);
var lyr_SoinKilla_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_SoinKilla_5, 
                style: style_SoinKilla_5,
                popuplayertitle: 'Soin Killa',
                interactive: true,
                title: '<img src="styles/legend/SoinKilla_5.png" /> Soin Killa'
            });
var format_Soin_6 = new ol.format.GeoJSON();
var features_Soin_6 = format_Soin_6.readFeatures(json_Soin_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:4326'});
var jsonSource_Soin_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Soin_6.addFeatures(features_Soin_6);
var lyr_Soin_6 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Soin_6, 
                style: style_Soin_6,
                popuplayertitle: 'Soin',
                interactive: true,
                title: '<img src="styles/legend/Soin_6.png" /> Soin'
            });

lyr_GoogleSatellite_0.setVisible(true);lyr_Kotla_AhmadKilla_1.setVisible(false);lyr_KotlaAhmad_2.setVisible(false);lyr_Kotla_BakhuKilla_3.setVisible(false);lyr_KotlaBakhu_4.setVisible(false);lyr_SoinKilla_5.setVisible(false);lyr_Soin_6.setVisible(false);
var layersList = [lyr_GoogleSatellite_0,lyr_Kotla_AhmadKilla_1,lyr_KotlaAhmad_2,lyr_Kotla_BakhuKilla_3,lyr_KotlaBakhu_4,lyr_SoinKilla_5,lyr_Soin_6];
lyr_Kotla_AhmadKilla_1.set('fieldAliases', {'Killa': 'Killa', 'Murabba_No': 'Murabba_No', 'Tehsil': 'Tehsil', 'Tehsil_ID': 'Tehsil_ID', 'Mouza': 'Mouza', 'Mouza_ID': 'Mouza_ID', 'Type': 'Type', 'M': 'M', 'A': 'A', 'K': 'K', 'SK': 'SK', 'Label': 'Label', 'B': 'B', 'MN': 'MN', 'OBJECTID': 'OBJECTID', });
lyr_KotlaAhmad_2.set('fieldAliases', {'Murabba_No': 'Murabba_No', });
lyr_Kotla_BakhuKilla_3.set('fieldAliases', {'Killa': 'Killa', 'Murabba_No': 'Murabba_No', 'Tehsil': 'Tehsil', 'Tehsil_ID': 'Tehsil_ID', 'Mouza': 'Mouza', 'Mouza_ID': 'Mouza_ID', 'Type': 'Type', 'M': 'M', 'A': 'A', 'K': 'K', 'SK': 'SK', 'Label': 'Label', 'B': 'B', 'MN': 'MN', 'OBJECTID': 'OBJECTID', });
lyr_KotlaBakhu_4.set('fieldAliases', {'Murabba_No': 'Murabba_No', });
lyr_SoinKilla_5.set('fieldAliases', {'Killa': 'Killa', 'Murabba_No': 'Murabba_No', 'Tehsil': 'Tehsil', 'Tehsil_ID': 'Tehsil_ID', 'Mouza': 'Mouza', 'Mouza_ID': 'Mouza_ID', 'Type': 'Type', 'M': 'M', 'A': 'A', 'K': 'K', 'SK': 'SK', 'Label': 'Label', 'B': 'B', 'MN': 'MN', 'OBJECTID': 'OBJECTID', });
lyr_Soin_6.set('fieldAliases', {'Murabba_No': 'Murabba_No', });
lyr_Kotla_AhmadKilla_1.set('fieldImages', {'Killa': 'TextEdit', 'Murabba_No': 'TextEdit', 'Tehsil': 'TextEdit', 'Tehsil_ID': 'Range', 'Mouza': 'TextEdit', 'Mouza_ID': 'Range', 'Type': 'TextEdit', 'M': 'Range', 'A': 'Range', 'K': 'Range', 'SK': 'TextEdit', 'Label': 'TextEdit', 'B': 'TextEdit', 'MN': 'Range', 'OBJECTID': 'Range', });
lyr_KotlaAhmad_2.set('fieldImages', {'Murabba_No': 'TextEdit', });
lyr_Kotla_BakhuKilla_3.set('fieldImages', {'Killa': 'TextEdit', 'Murabba_No': 'TextEdit', 'Tehsil': 'TextEdit', 'Tehsil_ID': 'Range', 'Mouza': 'TextEdit', 'Mouza_ID': 'Range', 'Type': 'TextEdit', 'M': 'Range', 'A': 'Range', 'K': 'Range', 'SK': 'TextEdit', 'Label': 'TextEdit', 'B': 'TextEdit', 'MN': 'Range', 'OBJECTID': 'Range', });
lyr_KotlaBakhu_4.set('fieldImages', {'Murabba_No': 'TextEdit', });
lyr_SoinKilla_5.set('fieldImages', {'Killa': 'TextEdit', 'Murabba_No': 'TextEdit', 'Tehsil': 'TextEdit', 'Tehsil_ID': 'Range', 'Mouza': 'TextEdit', 'Mouza_ID': 'Range', 'Type': 'TextEdit', 'M': 'Range', 'A': 'Range', 'K': 'Range', 'SK': 'TextEdit', 'Label': 'TextEdit', 'B': 'TextEdit', 'MN': 'Range', 'OBJECTID': 'Range', });
lyr_Soin_6.set('fieldImages', {'Murabba_No': 'TextEdit', });
lyr_Kotla_AhmadKilla_1.set('fieldLabels', {'Killa': 'header label - always visible', 'Murabba_No': 'no label', 'Tehsil': 'no label', 'Tehsil_ID': 'no label', 'Mouza': 'no label', 'Mouza_ID': 'no label', 'Type': 'no label', 'M': 'no label', 'A': 'no label', 'K': 'no label', 'SK': 'no label', 'Label': 'no label', 'B': 'no label', 'MN': 'no label', 'OBJECTID': 'no label', });
lyr_KotlaAhmad_2.set('fieldLabels', {'Murabba_No': 'inline label - always visible', });
lyr_Kotla_BakhuKilla_3.set('fieldLabels', {'Killa': 'header label - always visible', 'Murabba_No': 'no label', 'Tehsil': 'no label', 'Tehsil_ID': 'no label', 'Mouza': 'no label', 'Mouza_ID': 'no label', 'Type': 'no label', 'M': 'no label', 'A': 'no label', 'K': 'no label', 'SK': 'no label', 'Label': 'no label', 'B': 'no label', 'MN': 'no label', 'OBJECTID': 'no label', });
lyr_KotlaBakhu_4.set('fieldLabels', {'Murabba_No': 'inline label - always visible', });
lyr_SoinKilla_5.set('fieldLabels', {'Killa': 'header label - always visible', 'Murabba_No': 'no label', 'Tehsil': 'no label', 'Tehsil_ID': 'no label', 'Mouza': 'no label', 'Mouza_ID': 'no label', 'Type': 'no label', 'M': 'no label', 'A': 'no label', 'K': 'no label', 'SK': 'no label', 'Label': 'no label', 'B': 'no label', 'MN': 'no label', 'OBJECTID': 'no label', });
lyr_Soin_6.set('fieldLabels', {'Murabba_No': 'inline label - always visible', });
lyr_Soin_6.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});